interface BeatSheet {
  id: number,
  name: string,
  acts: Act[]
}