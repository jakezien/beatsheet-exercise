interface Act {
  id: number
  name: string
  beats?: Beat[]
}

