'use client'
import React, { Component, createContext, ReactNode } from 'react';
const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL


const defaultSheet: BeatSheet = {
  name: "",
  id: 0,
  acts: []
};


const BeatSheetContext = createContext<{
  sheet: BeatSheet;
  setSheet: (sheet: BeatSheet) => void;
}>({
  sheet: defaultSheet,
  setSheet: () => {}
});


interface Props {
  children: ReactNode
}

interface State {
  sheet: BeatSheet
}

class BeatSheetProvider extends React.Component<Props, State> {

  constructor(props: Props) {
    super(props);
    this.state = {
      sheet: defaultSheet
    };
  }
  
  async componentDidMount() {
    this.setSheet(await this.fetchInitialSheet())
  }

  // Fetching
  async fetchData<T>(url: string, errorText: string): Promise<T> {
    try {
      const res = await fetch(url);
      if (!res.ok) { throw new Error(`${errorText} ${res.statusText}`); }
      const data: T = await res.json();
      return data;
    } catch (error) {
      console.error(`${errorText} ${error}`);
      throw error;
    }
  }
  
  async fetchActs(): Promise<Act[]> {
    const url = `${baseUrl}/acts`
    const errorText = "Failed to fetch Acts.";
    return this.fetchData<Act[]>(url, errorText);
  }

  async fetchBeats(act: Act): Promise<Beat[]> {
    const url = `${baseUrl}/acts/${act.id}/beats`
    const errorText = "Failed to fetch Beats.";
    return this.fetchData<Beat[]>(url, errorText);
  }

  async fetchInitialSheet(): Promise<BeatSheet> {
    const acts = await this.fetchActs()
    await Promise.all(acts.map(async (act) => {
      const beats = await this.fetchBeats(act);
      act.beats = beats
    }));

    const beatSheet: BeatSheet = {
      name: "Beatsheet",
      id: 0, // TODO: don't hardcode these, set to value of last sheet
      acts: acts
    }

    return beatSheet
  }


  setSheet = (newSheet: BeatSheet) => {
    if (newSheet === this.state.sheet) { return }
    console.log('Setting sheet to: ', newSheet.acts.map((a,i)=>a.name));
    // console.trace()
    this.setState({sheet: newSheet})
  }
  
  render() {
    const { children } = this.props;
    const { sheet } = this.state;
    return (
      <BeatSheetContext.Provider value={{ sheet, setSheet: this.setSheet }}>
        {children}
      </BeatSheetContext.Provider>
    );
  }
}

// Custom hook to use this context
export const useBeatSheet = () => {
  const context = React.useContext(BeatSheetContext);
  if (!context) {
    throw new Error('useBeatSheet must be used within a BeatSheetProvider.');
  }
  return context;
};

export default BeatSheetProvider;